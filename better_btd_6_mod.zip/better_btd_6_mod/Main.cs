﻿using System;
using Assets.Scripts.Simulation.Towers.Weapons;
using Assets.Scripts.Unity;
using Assets.Scripts.Unity.UI_New.InGame;
using Assets.Scripts.Unity.UI_New.Popups;
using Assets.Scripts.Utils;
using BTD_Mod_Helper;
using BTD_Mod_Helper.Extensions;
using HarmonyLib;
using TMPro;
using UnityEngine;

namespace better_btd_6_mod
{
	public class Main : BloonsTD6Mod
	{
		public override void OnApplicationStart()
		{
			base.OnApplicationStart();
		}

		public override void OnMatchStart()
		{
			GameExt.ShowMessage(Game.instance, "Mod Menu Loaded...", null);
			base.OnMatchStart();
		}

		public override void OnUpdate()
		{
			bool flag = InGame.instance != null && InGame.instance.bridge != null;
			bool flag2 = flag;
			if (flag2)
			{
				bool flag3 = Main.Hotkeyd && PopupScreen.instance.GetFirstActivePopup() != null;
				if (flag3)
				{
					PopupScreen.instance.GetFirstActivePopup().GetComponentInChildren<TMP_InputField>().characterValidation = 0;
					Main.Hotkeyd = false;
				}
				bool keyDown = Input.GetKeyDown((KeyCode)282);
				if (keyDown)
				{
					Action<string> action = delegate (string s)
					{
						InGameExt.AddCash(InGame.instance, (double)int.Parse(s));
					};
					PopupScreen.instance.ShowSetNamePopup("Add Money (Game Options)", "Input Your Value!", action, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown2 = Input.GetKeyDown((KeyCode)283);
				if (keyDown2)
				{
					Action<string> action2 = delegate (string s)
					{
						InGameExt.AddHealth(InGame.instance, (double)int.Parse(s));
					};
					PopupScreen.instance.ShowSetNamePopup("Add Health (Game Options)", "Input Your Value!", action2, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown3 = Input.GetKeyDown((KeyCode)284);
				if (keyDown3)
				{
					Action<string> action3 = delegate (string s)
					{
						InGameExt.SetRound(InGame.instance, int.Parse(s));
					};
					PopupScreen.instance.ShowSetNamePopup("Set Round (Game Options)", "Input Your Value!", action3, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown4 = Input.GetKeyDown((KeyCode)285);
				if (keyDown4)
				{
					Action<string> action4 = delegate (string s)
					{
						InGame.instance.bridge.SetSandboxHealth((float)int.Parse(s));
					};
					PopupScreen.instance.ShowSetNamePopup("Set Sandbox Health (Game Options)", "Input Your Value!", action4, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown5 = Input.GetKeyDown((KeyCode)286);
				if (keyDown5)
				{
					Action<string> action5 = delegate (string s)
					{
						Main.amount = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Set Projectile Speed (Game Options)", "Input Your Value!", action5, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown26 = Input.GetKeyDown((KeyCode)287);
				if (keyDown26)
				{
					Action<string> action26 = delegate (string s)
					{
						InGame.instance.bridge.simulation.shield = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Change Shield (Game Options)", "Input Your Value!", action26, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown6 = Input.GetKeyDown((KeyCode)256);
				if (keyDown6)
				{
					Action<string> action6 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.goldKeys = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Gold Keys (Account Options)", "Input Your Value! (This May Not Work)", action6, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown7 = Input.GetKeyDown((KeyCode)257);
				if (keyDown7)
				{
					Action<string> action7 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.goldenBloonsPopped = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Golden Bloon's Popped (Account Options)", "Input Your Value!", action7, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown8 = Input.GetKeyDown((KeyCode)258);
				if (keyDown8)
				{
					Action<string> action8 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.knowledgePoints = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Knowledge Points (Account Options)", "Input Your Value!", action8, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown9 = Input.GetKeyDown((KeyCode)259);
				if (keyDown9)
				{
					Action<string> action9 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.monkeyMoney = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Monkey Money (Account Options)", "Input Your Value!", action9, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown10 = Input.GetKeyDown((KeyCode)260);
				if (keyDown10)
				{
					Action<string> action10 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.silverKeys = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Silver Keys (Account Options)", "Input Your Value! (This May Not Work)", action10, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown11 = Input.GetKeyDown((KeyCode)261);
				if (keyDown11)
				{
					Action<string> action11 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.monkeyTeamsWins = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Monkey Team Wins (Account Options)", "Input Your Value! (This May Not Work)", action11, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown12 = Input.GetKeyDown((KeyCode)262);
				if (keyDown12)
				{
					Action<string> action12 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.bronzeKeys = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Bronze Keys (Account Options)", "Input Your Value! (This May Not Work)", action12, "0");
					Main.Hotkeyd = true;
				}
				bool keyDown13 = Input.GetKeyDown((KeyCode)263);
				if (keyDown13)
				{
					Action<string> action13 = delegate (string s)
					{
						Game.instance.playerService.Player.Data.lifetimeTrophies = int.Parse(s);
					};
					PopupScreen.instance.ShowSetNamePopup("Life Time Trophies (Account Options)", "Input Your Value! (This May Not Work)", action13, "0");
					Main.Hotkeyd = true;
				}
			}
		}

		private static int amount;

		private static bool Hotkeyd;

		public static bool definitelyTryPlaceNext;

		public class Awake_Patch
		{
		}

		[HarmonyPatch(typeof(Weapon), "Initialise")]
		public class weaponInitialise_Patch
		{
			[HarmonyPostfix]
			public static void Postfix(Weapon __instance)
			{
				__instance.weaponModel.Rate = (float)Main.amount;
				__instance.weaponModel.rate = (float)Main.amount;
			}
		}
	}
}
