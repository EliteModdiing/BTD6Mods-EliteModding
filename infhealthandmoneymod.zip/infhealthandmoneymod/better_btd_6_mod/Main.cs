﻿using System;
using Assets.Scripts.Simulation.Towers.Weapons;
using Assets.Scripts.Unity;
using Assets.Scripts.Unity.UI_New.InGame;
using Assets.Scripts.Unity.UI_New.Popups;
using Assets.Scripts.Utils;
using BTD_Mod_Helper;
using BTD_Mod_Helper.Extensions;
using HarmonyLib;
using TMPro;
using UnityEngine;

namespace btd6_overhaul
{
	public class Main : BloonsTD6Mod
	{
		public override void OnApplicationStart()
		{
			base.OnApplicationStart();
		}

		public override void OnMatchStart()
		{
			GameExt.ShowMessage(Game.instance, "BTD 6 INF MONEY AND HEALTH MOD Loaded...", null);
			base.OnMatchStart();
		}

		public override void OnUpdate()
		{
			bool flag = InGame.instance != null && InGame.instance.bridge != null;
			bool flag2 = flag;
			if (flag2)
			{
				InGame.instance.AddCash(99999999);
				InGame.instance.AddHealth(99999999);
				Game.instance.playerService.Player.Data.monkeyMoney = 99999999;
			}
		}

		public class Awake_Patch
		{
		}

		[HarmonyPatch(typeof(Weapon), "Initialise")]
		public class weaponInitialise_Patch
		{
			[HarmonyPostfix]
			public static void Postfix(Weapon __instance)
			{
				__instance.weaponModel.Rate = 0;
			}
		}
	}
}
